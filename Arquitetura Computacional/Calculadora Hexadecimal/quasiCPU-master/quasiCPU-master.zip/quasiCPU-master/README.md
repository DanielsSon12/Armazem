# quasiCPU
Um modelo didático de implementação de uma CPU
